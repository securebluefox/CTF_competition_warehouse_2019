from Crypto.Cipher import AES
from Crypto import Random
from string import ascii_letters
from random import choice,randint
import sys
import signal

KEY = b'JustKey not fl@g'
FLAG = '********'

def pad(s, block_size):
    return s + (block_size - len(s) % block_size) * chr(block_size - len(s) % block_size)

def check_pad(s, block_size):
    assert len(s) % block_size == 0
    assert ord(s[-1]) <= block_size
    for i in range(ord(s[-1])):
        assert s[-1-i] == s[-1]
    return s[:-1-i]

def gen_user():
    name = ''.join(choice(ascii_letters) for x in range(randint(8,12)))
    iv = Random.new().read(AES.block_size)
    cipher = AES.new(KEY, AES.MODE_CBC, iv)
    cipher_text = iv + cipher.encrypt(pad(name, AES.block_size))
    return cipher_text.encode("hex")


def check_user(cipher_text):
    if len(cipher_text) <= AES.block_size or len(cipher_text) % AES.block_size != 0:
        print "format wrong"
        sys.stdout.flush()
        return
    cipher = AES.new(KEY, AES.MODE_CBC, cipher_text[:16])
    plain_text = cipher.decrypt(cipher_text[16:])
    try:
        plain_text = check_pad(plain_text, AES.block_size)
    except:
        print "padding error"
        sys.stdout.flush()
        return
    if plain_text == 'Admin':
        print "Welcome admin, your flag is %s" % FLAG
        sys.stdout.flush()
        return
    else:
        print "YOU. SHALL. NOT. PASS!"
        sys.stdout.flush()
        return
    

def main():
    passport = gen_user()
    print "Hey, new! Your passport is %s" % passport
    print "Now you'd better prove me that you are noble. Or get away in 10 minutes!"
    sys.stdout.flush()
    while (1):
        try:
	    check_passport = raw_input().strip()
        except EOFError:
            break
        try:
            check_passport = check_passport.decode("hex")
        except:
            print "format wrong"
            sys.stdout.flush()
            continue
        check_user(check_passport)

if __name__ == "__main__":
    signal.alarm(600)
    main()
