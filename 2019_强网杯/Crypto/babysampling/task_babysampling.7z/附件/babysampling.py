import hashlib
import secret
flag=secret.flag
assert flag.startswith("flag{")
assert flag.endswith("}")
assert len(flag)==38
assert hashlib.sha256(flag).hexdigest()=="bdde9837d5228a9ff33c00be1daf46489b7dafdd88750827e93d0dbd56477e7c"

def lfsr(R,mask):
	firstbit = (R >>128) & 0x1
	R_skr = (R << 1) & 0x1ffffffffffffffffffffffffffffffff
	i= (R & mask) & 0x1ffffffffffffffffffffffffffffffff
	lastbit=0
	while i!=0:
		lastbit^=(i&1)
		i=i>>1
	R_skr^=lastbit
	return R_skr,firstbit

R=int(flag[5:37],16)
mask=secret.mask
''' in secret.py
from sympy.polys.domains import ZZ
from sympy.polys.galoistools import gf_irreducible
tmp=gf_irreducible(128, 2, ZZ)
r=0
for i in range(len(tmp)):
	r=(r<<1)
	r^=tmp[i]
mask=r
'''

s=""
for i in range(131072):
	tmp=0
	for j in range(8):
		(R,firstbit)=lfsr(R,mask)
		tmp = (tmp << 1) ^ firstbit
		(R,firstbit)=lfsr(R,mask)
		(R,firstbit)=lfsr(R,mask)
	s+=chr(tmp)
open("output","wb").write(s)