import hashlib
import secret
flag=secret.flag
assert flag.startswith("flag{")
assert flag.endswith("}")
assert len(flag)==38
assert hashlib.sha256(flag).hexdigest()=="d67c35a8f45e9c36c9bdb0e73027a3f89aa3bdd940cc200d7f0655af7f0a8dba"

def lfsr(R,mask):
    R_skr = (R << 1) & 0x1ffffffffffffffffffffffffffffffff
    i= (R & mask) & 0x1ffffffffffffffffffffffffffffffff
    lastbit=0
    while i!=0:
        lastbit^=(i&1)
        i=i>>1
    R_skr^=lastbit
    return (R_skr,lastbit)

R=int(flag[5:37],16)
mask=secret.mask
''' in secret.py
from sympy.polys.domains import ZZ
from sympy.polys.galoistools import gf_irreducible
tmp=gf_irreducible(128, 2, ZZ)
r=0
for i in range(len(tmp)):
	r=(r<<1)
	r^=tmp[i]
mask=r
'''

s=""
for i in range(131072):
	tmp=0
	for j in range(8):
		(R,lastbit)=lfsr(R,mask)
		tmp = (tmp << 1) ^ lastbit
		(R,lastbit)=lfsr(R,mask)
		(R,lastbit)=lfsr(R,mask)
		(R,lastbit)=lfsr(R,mask)
		(R,lastbit)=lfsr(R,mask)
		(R,lastbit)=lfsr(R,mask)
		(R,lastbit)=lfsr(R,mask)
	s+=chr(tmp)
open("output","wb").write(s)