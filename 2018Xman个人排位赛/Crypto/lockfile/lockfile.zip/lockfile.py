#!/usr/bin/env python3
import sys
import hashlib
from AESCipher import *


class FileLocker(object):

    def __init__(self, keys):
        assert len(keys) == 4
        self.keys = keys
        self.ciphers = []
        for i in range(4):
            self.ciphers.append(AESCipher(keys[i]))

    def enc(self, plaintext):
        stage1 = self.ciphers[0].encrypt(plaintext)
        stage2 = self.ciphers[1].encrypt(stage1)
        stage3 = self.ciphers[2].encrypt(stage2)
        ciphertext = self.ciphers[3].encrypt(stage3)
        return ciphertext

    def dec(self, ciphertext):
        stage3 = AESCipher._unpad(self.ciphers[3].decrypt(ciphertext))
        stage2 = AESCipher._unpad(self.ciphers[2].decrypt(stage3))
        stage1 = AESCipher._unpad(self.ciphers[1].decrypt(stage2))
        plaintext = AESCipher._unpad(self.ciphers[0].decrypt(stage1))
        return plaintext


if __name__ == "__main__":
    if len(sys.argv) != 3:
        # PASSWORD SHOULD BE Visible character
        print("Usage: ./lockfile.py plainfile password")
        exit()

    filename = sys.argv[1]
    plaintext = open(filename, "rb").read()

    password = sys.argv[2].encode('utf-8')
    assert len(password) == 8
    i = len(password) / 4
    keys = [
        hashlib.sha256(password[0:i]).digest(),
        hashlib.sha256(password[i:2 * i]).digest(),
        hashlib.sha256(password[2 * i:3 * i]).digest(),
        hashlib.sha256(password[3 * i:4 * i]).digest(),
    ]
    s = FileLocker(keys)

    ciphertext = s.enc(plaintext)

    open(filename + ".encrypted", "w").write(ciphertext)
