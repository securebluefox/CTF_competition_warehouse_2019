from libnum import *
from Crypto.Util.number import *
from gmpy2 import next_prime
from flag import flag
flag = s2n(flag)
a = getRandomRange(pow(10,499),pow(10,500))
b = getRandomRange(pow(10,499),pow(10,500))
p = a*pow(10,500)+b
q = b*pow(10,500)+a
print p*q
e = 65537
c = getRandomInteger(100)
p = next_prime(p+c)
q = next_prime(q+c)
n = p*q
print n
flag = pow(flag,e,n)
print flag




