from Crypto.Cipher import DES

with open('key.txt', 'r') as r:
    KEY = r.read()
    IV = 'Le3tc0de'
des = DES.new(KEY, DES.MODE_OFB, IV)

with open('plain.txt', 'r') as r:
    plain = r.read()

with open('cipher.txt', 'w') as w:
    cipher = des.encrypt(plain)
    w.write(cipher)
