def rotl2(a):
    return (((a<<2) | (a>>6)) & 0xff)

def leftHalf(a):
    return ((a >> 32) & 0xFFFFFFFF)

def rightHalf(a):
    return (a & 0xFFFFFFFF)

def sepByte(a, index):
    return ((a >> (8 * index)) & 0xFF)

def combinebBytes(b3, b2, b1, b0):
    return (((b3 << 24) | (b2 << 16) | (b1 << 8) | (b0)) & 0xFFFFFFFF)

def combineHalves(leftHalf, rightHalf):
    return (((leftHalf << 32) | (rightHalf & 0xFFFFFFFF)) & 0xFFFFFFFFFFFFFFFF)

def gBox(a, b, delta):
    return rotl2((a + b + delta) & 0xff)

def fBox(plain):
    x0 = sepByte(plain, 0)
    x1 = sepByte(plain, 1)
    x2 = sepByte(plain, 2)
    x3 = sepByte(plain, 3)

    t0 = (x2 ^ x3)

    y1 = gBox(x0 ^ x1, t0, 1)
    y0 = gBox(x0, y1, 0)
    y2 = gBox(y1, t0, 0)
    y3 = gBox(y2, x3, 1)
    return combinebBytes(y3, y2, y1, y0)


def encrypt(plain, subkey):
    assert b'cat' not in plain.to_bytes(8, 'big')
    left, right = leftHalf(plain), rightHalf(plain)

    left ^= subkey[6]
    right ^= subkey[7] ^ left

    for i in range(6):
        left, right = right, left ^ fBox(right ^ subkey[i])

    cipherLeft, cipherRight = right, left ^ right

    return combineHalves(cipherLeft, cipherRight)

def decrypt(cipher, subkey):
    cipherLeft, cipherRight = leftHalf(cipher), rightHalf(cipher)

    left, right = cipherLeft ^ cipherRight, cipherLeft

    for i in range(5, -1, -1):
        left, right = right ^ fBox(left ^ subkey[i]), left

    right ^= subkey[7] ^ left
    left ^= subkey[6]

    return combineHalves(left, right)