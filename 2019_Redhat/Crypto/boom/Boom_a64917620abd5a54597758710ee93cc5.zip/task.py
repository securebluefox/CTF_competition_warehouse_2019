#!/usr/bin/env python3
# coding=utf-8
import os,sys,random,subprocess,string,binascii
from hashlib import sha256
import socketserver

import Feal6

class Task(socketserver.BaseRequestHandler):
    def __init__(self, *args, **kargs):
        self.subkey = []
        super().__init__(*args, **kargs)

    def proof_of_work(self):
        random.seed( os.urandom(8) )
        proof = ''.join( [ random.choice(string.ascii_letters+string.digits) for _ in range(20) ] )
        digest = sha256( proof.encode() ).hexdigest()
        self.dosend( str.encode( ( "sha256(XXXX+%s) == %s\n" % (proof[4:],digest) ) ) )
        self.dosend( str.encode('Give me XXXX:') )
        x = self.request.recv(10)
        x = ( x.strip() ).decode("utf-8") 
        if len(x) != 4 or sha256( (x+proof[4:]).encode() ).hexdigest() != digest: 
            return False
        return True

    def dosend(self, msg):
        try:
            self.request.sendall(msg+b'\n')
        except:
            pass

    def recvall(self):
        BUFF_SIZE = 2048
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data

    def pad(self, s): 
        return s + bytes( [-len(s) % 8]*(-len(s) % 8) )
    
    def unpad(self, s):
        ss = s[ :-s[-1] ]
        if self.pad(ss) == s:
            return ss
        else:
            return s

    def genkeys(self):
        return [ random.randint(2**32,2**33) for i in range(8) ]

    def encrypt(self, msg):
        msg = self.pad(msg)
        iv = msg[:8]
        pt = msg[8:]
        Emm = int.from_bytes(iv, 'big')
        Em = Feal6.encrypt(Emm, self.subkey)
        out = iv
        for i in range(len(pt) // 8):
            mb = int.from_bytes(pt[i * 8: (i + 1) * 8], 'big')
            block = mb ^ Em
            block = Feal6.encrypt(block, self.subkey)
            cb = block ^ Emm
            out += cb.to_bytes(8, 'big')
            Em = cb
            Emm = mb
        return out

    def decrypt(self, msg):
        assert len(msg) % 8 == 0
        iv = msg[:8]
        ct = msg[8:]
        Emm = int.from_bytes(iv, 'big')
        Em = Feal6.encrypt(Emm, self.subkey)
        out = iv
        for i in range(len(ct) // 8):
            cb = int.from_bytes(ct[i * 8: (i + 1) * 8], 'big')
            block = cb ^ Emm
            block = Feal6.decrypt(block, self.subkey)
            mb = block ^ Em
            out += mb.to_bytes(8, 'big')
            Emm = mb
            Em = cb
        return self.unpad(out)

    def handle(self):
        if not self.proof_of_work():
            return
        self.subkey = self.genkeys()
        self.dosend(b"Welcome to the secret server.\nLet\'s boom!!!\n")
        while True:
            try:
                cmd = self.recvall().strip()

                if cmd == b'/exit':
                    self.dosend(b"Good bye!")
                    break

                elif cmd.startswith(b'/enc '):
                    msg = binascii.unhexlify( cmd[4:].strip() )
                    enc = self.encrypt(msg)
                    self.dosend( binascii.hexlify(enc) )

                elif cmd.startswith(b'/dec '):
                    enc = binascii.unhexlify( cmd[4:].strip() )
                    msg = self.decrypt(enc)
                    self.dosend( binascii.hexlify(msg) )

                elif cmd.startswith(b'/cmd '):
                    enc = binascii.unhexlify( cmd[4:].strip() )
                    msg = Feal6.decrypt(int.from_bytes(enc[:8],'big'), self.subkey)
                    msg = msg.to_bytes(8, 'big')
                    bash_cmd = msg.strip(b'\x00').split()
                    if bash_cmd[0] not in [b'cat', b'ls', b'pwd']:
                        break
                    out = subprocess.check_output(bash_cmd)
                    self.dosend(out)

                else:
                    break

            except Exception:
                self.dosend("Rua!!!")
                break

        self.dosend( str.encode("Rua!!!") )
        self.request.close()

        
        

class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass

if __name__ == "__main__":
    HOST, PORT = '127.0.0.1', 10000
    server = ThreadedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()