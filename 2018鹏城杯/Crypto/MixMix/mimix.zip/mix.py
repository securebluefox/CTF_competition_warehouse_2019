import os
import primefac
import random
from Crypto.Util.number import getPrime,long_to_bytes,bytes_to_long
flag=open("flag","rb").read()
print "++good good study, day day up++"
fout=open("output","wb")
def pad(m):
    tmp=m+os.urandom(16-len(m) % 16)
    if (len(tmp)/16) % 2 !=0:
        tmp+=os.urandom(16)
    return tmp
m=pad(flag)

def cipher1(m):
    tmp= bytes_to_long(os.urandom(172)+m)
    e=3
    p=getPrime(1024)
    q=getPrime(1024)
    n=p*q
    c=pow(tmp,e,n)
    d=primefac.modinv(e,(p-1)*(q-1)) % ((p-1)*(q-1))
    if pow(c,d,n)!=tmp:
        return cipher1(m)
    else:
        fout.write(long_to_bytes(n).encode("hex") + "\n")
        fout.write(long_to_bytes(c).encode("hex") + "\n")
        return long_to_bytes(d)[-len(long_to_bytes(d))/2-1:]
t=cipher1(m)
def pad2(m):
    assert len(m)<256
    return os.urandom(256-len(m))+m
t=pad2(t)
def generateBOX():
    for i in range(624):
        tmp=random.getrandbits(32)
        fout.write(long_to_bytes(tmp).encode("hex")+"\n")
    BOX=[]
    for i in range(32):
        BOX.append(random.getrandbits(1024))
    return BOX
BOX=generateBOX()
def pad_128(m):
    assert len(m)<=128
    if len(m)==127:
        return '\x00'+m
    if len(m)==128:
        return m
    assert False
def singleround(m):
    L=bytes_to_long(m[0:128])
    R=bytes_to_long(m[128:256])
    nL=R
    nR=L^BOX[R%32]
    return pad_128(long_to_bytes(nL))+pad_128(long_to_bytes(nR))
def cipher2(m):
    tmp=m
    for i in range(32):
        tmp=singleround(tmp)
    return tmp
cc=cipher2(t).encode("hex")
fout.write(cc+"\n")