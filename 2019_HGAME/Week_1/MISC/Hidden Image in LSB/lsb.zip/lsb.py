# coding=utf-8
# author=oyiadin

# Jan 18, 2019
# Welcome to HCTF Game 2019, have fun!

# command: python lsb.py --watermark -ir original-power-source.png -iw flag.png -o power-source.png

import argparse
import numpy as np
from PIL import Image


parser = argparse.ArgumentParser(
    description='An implement of image steganography')

add_or_extract_group = parser.add_mutually_exclusive_group(required=True)

add_or_extract_group.add_argument(
    '--watermark', default=False, action='store_const', const=True)
add_or_extract_group.add_argument(
    '--extract', default=False, action='store_const', const=True)

parser.add_argument('-ir', type=str, metavar='IN_FILE', required=True)
parser.add_argument('-iw', type=str, metavar='IN_FILE', required=False)
parser.add_argument('-o', type=str, metavar='OUT_FILE', required=True)


def apply_watermark(ir: Image, iw: Image, o: str):
    # ir: image_raw, iw: image_watermark, o: output_image
    wd, ht = ir.size
    ir = ir.convert('RGB')
    iw = iw.convert('RGB')

    ir = (np.array(ir.getdata()) >> 2) << 2
    iw = np.array(iw.resize((wd, ht)).getdata())
    iw = np.vectorize(lambda x: int(round(x / 85)) ^ 0b10)(iw)

    mix = (ir + iw).reshape((ht, wd, 3)).astype('uint8')
    im = Image.fromarray(mix).convert('RGB')
    im.save(o)

    return im


def extract_watermark(ir, o):
    raise NotImplementedError


if __name__ == '__main__':
    args = parser.parse_args()
    try:
        ir = Image.open(args.ir) if args.ir else None
        iw = Image.open(args.iw) if args.iw else None
        o = args.o

        if args.watermark:
            apply_watermark(ir, iw, o)
        elif args.extract:
            extract_watermark(ir, o)

    except FileNotFoundError as e:
        print('FileNotFoundError:', e)

    except AssertionError as e:
        print('AssertionError:', e)
