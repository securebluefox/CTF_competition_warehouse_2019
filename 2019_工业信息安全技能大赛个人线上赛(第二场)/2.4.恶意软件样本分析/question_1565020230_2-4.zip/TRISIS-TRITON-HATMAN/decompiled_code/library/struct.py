# uncompyle6 version 2.14.1
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.12 (default, Nov 19 2016, 06:48:10) 
# [GCC 5.4.0 20160609]
# Embedded file name: struct.pyc
# Compiled at: 2016-06-25 21:46:10
from _struct import *
from _struct import _clearcache
from _struct import __doc__