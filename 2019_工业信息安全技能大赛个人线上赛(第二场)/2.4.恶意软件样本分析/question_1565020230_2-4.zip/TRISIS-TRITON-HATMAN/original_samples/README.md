| Name       | MD5                              | Contains        | MD5                              |
| ---------- | -------------------------------- | --------------- | -------------------------------- |
| trilog.7z  | 0b4e76e84fa4d6a9716d89107626da9b | trilog.exe      | 6c39c3f4a08d3d78f2eb973a94bd7718 |
| library.7z | 76f84d3aee53b2856575c9f55a9487e7 | library.zip     | 0face841f7b2953e7c29c064d6886523 |
| imain.7z   | d173e8016e73f0f2c17b5217a31153be | imain.bin       | 437f135ba179959a580412e564d3107f |
| all.7z     | 5472e9e6d7fcb34123286878e1fecf85 | All files above | -                                |

All archives are secured with password: *infected*

**Any updates to the repository are warmly welcome**

Currently looking for the missing *inject.bin (0544d425c7555dc4e9d76b571f31f500)* file

Contact: 

- [@dudekmar](https://twitter.com/dudekmar)
- contact(at)marcindudek.com