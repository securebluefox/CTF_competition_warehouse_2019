import sys 
import os
import subprocess

size_max = 50000


def start():
     print "======================================"
     print "we find another bug in hitcon2018-abyss and  fixed previous bug."
     print "Source can be found at https://github.com/david942j/ctf-writeups/tree/master/hitcon-2018/abyss"
     print "Now, you can upload a dynamically linked elf."
     print "And we will execute \'./hypervisor.elf  kernel.bin ld.so.2 ./user.elf [args...] \'"
     print "You need to read flag2 to get flag."
     print "======================================"
     sys.stdout.flush()
  
     print "elf len>"
     sys.stdout.flush()
     clen = int(input())
     
     if  size_max < clen:
        print 'elf too long!'
        sys.stdout.flush()
        exit(0)
     print "code>"
     sys.stdout.flush()
     code = ''
     for i in range(clen):
        code += sys.stdin.read(1)

     fp = open("./user.elf","w+")
     fp.write(code)
     fp.close()
     
     print "xargs len>"
     sys.stdout.flush()

     xlen = int(input())
     if  0x3000 < xlen:
        print 'args too long!'
        sys.stdout.flush()
        exit(0)
     print "xargs>"
     sys.stdout.flush()
     
     xargs=''
     for i in range(xlen):
        xargs += sys.stdin.read(1)

     cmd = './hypervisor.elf  kernel.bin ld.so.2 ./user.elf '+xargs
     
     proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
     
     while True:
        line = proc.stdout.readline()
        if line != '':
            print(line)
            sys.stdout.flush()
        if subprocess.Popen.poll(proc)==0: 
            break
        
     




if __name__ == "__main__":
    start()