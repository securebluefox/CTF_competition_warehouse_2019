from torchvision import transforms
from resnet import *
from PIL import Image
import torch
import numpy as np
device = 'cuda' if torch.cuda.is_available() else 'cpu'
classes = ('airplane', 'automobile', 'bird', 'cat', 'deer',
           'dog', 'frog', 'horse', 'ship', 'truck')
model = ResNet18()
model = model.to(device)
model = torch.nn.DataParallel(model)
model.load_state_dict(torch.load(
    'ckpt.pth', map_location=torch.device(device))['net'])
model.eval()
transform_pipeline = transforms.Compose([transforms.ToTensor(
), transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])


def distance(X, Y):
    assert X.dtype == np.uint8
    assert Y.dtype == np.uint8
    X = X.astype(np.float64) / 255
    Y = Y.astype(np.float64) / 255
    return np.linalg.norm(X - Y)


score = 2.4

for c in classes:
    img = transform_pipeline(Image.open(
        'submission_example/{}-adv.png'.format(c)))
    img = img.unsqueeze(0)
    outputs = model(img).detach().numpy()[0]
    assert np.argmax(outputs) == 3

    score -= distance(np.asarray(Image.open('origin_images/{}.png'.format(c))),
                      np.asarray(Image.open('submission_example/{}-adv.png'.format(c))))
score = max(int(score*1000), -1000)
print score
