note: the result of 
```
from hashlib import md5, sha1
md5(sha1(flag).hexdigest()).hexdigest()
```
 is 'deef2d4b48af6b75ed07fd3d7ccc4d8f'