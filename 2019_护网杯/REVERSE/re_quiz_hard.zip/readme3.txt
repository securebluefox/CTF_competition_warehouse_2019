<----flag input censored---->
611d255bb260fbd2f65e3fea6b5ade61
1cb53f1b624e436bca54b3aae8feb648

note: the result of 
```
from hashlib import md5, sha1
md5(sha1(flag).hexdigest()).hexdigest()
```
 is 'c4d83cc1ce105cea8220e1eebf3ce8ff'