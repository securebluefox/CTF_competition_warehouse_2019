from hashlib import sha256
from flag import secret1, secret2


def list_to_hash(l):
    return ''.join(map(lambda x: hex(x)[2:].strip('L').rjust(8, '0'), l))


def hash1(message):
    k0, k1, sum = 0x12345678, 0x87654321, 0xcf10f051
    for _ in range(0xFF):
        k1 = (k1 - (((k0 << 4) + message[2]) ^ (k0 + sum)
                    ^ ((k0 >> 5) + message[3]))) & 0xffffffff
        k0 = (k0 - (((k1 << 4) + message[0]) ^ (k1 + sum)
                    ^ ((k1 >> 5) + message[1]))) & 0xffffffff
        sum = (sum - 0xdeadbeaf) & 0xffffffff
    return list_to_hash([k0, k1])


def ROL(data, n):
    shift = data << n
    shift &= 0xffffffff
    carry = data >> (32 - n)
    return shift | carry


def ROR(data, n):
    shift = data >> n
    carry = data << (32 - n)
    carry &= 0xffffffff
    return shift | carry


def hash2(message):
    hashdata = []
    for block in message:
        block ^= 0x12345678
        block = ROR(block, block & 0xF)
        block = (block + 0x87654321) & 0xffffffff
        block = ROL(block, block & 0xF)
        block = (block * 0xdeadbeaf) & 0xffffffff
        if hashdata:
            hashdata.append(block ^ hashdata[-1])
        else:
            hashdata.append(block)
    return list_to_hash(hashdata)


message = [0xf5785dfb, 0x4065f2d2, 0x9742c06d, 0x385bd451]

# Level 1
assert hash1(secret1) == hash1(message)
assert all(map(lambda x: 0 <= x <= 0xffffffff, secret1))
assert message != secret1

# Level 2
assert hash2(secret2) == '51059dd0e23f4874a8aef600a6979501'
assert all(map(lambda x: 0 <= x <= 0xffffffff, secret2))

# If you got multiple solutions, check this.
assert sha256(list_to_hash(secret1)).hexdigest(
) == 'e369aedb1dfa5cb690260d5afffbb02b40ad795d3e5450c5fbf1ce8f7c3ce55b'
assert sha256(list_to_hash(secret2)).hexdigest(
) == '5cf363de99aa47f535079070e63e38cf6d4fba907e33f5601fac7521cd04ab93'

print 'Congratulations! The flag is flag{' + sha256(list_to_hash(secret1)+list_to_hash(secret2)).hexdigest() + '}'
