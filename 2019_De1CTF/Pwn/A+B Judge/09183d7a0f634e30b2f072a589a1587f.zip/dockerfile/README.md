an simplified online judge
you can start it via this command
```
docker-compose up -d
```
the server will listen on port 9999