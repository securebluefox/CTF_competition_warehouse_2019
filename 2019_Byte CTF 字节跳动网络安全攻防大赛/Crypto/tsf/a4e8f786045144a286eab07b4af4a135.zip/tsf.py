import secret
from Crypto.Util.number import long_to_bytes
import hashlib

def lfsr(R,mask,degree):
    f_skr = (1 << degree) - 1
    tmp = ((R << 1) & mask) & f_skr
    lastbit=0
    while tmp!=0:
        lastbit^=(tmp&1)
        tmp=tmp>>1
    return (((R << 1) ^ lastbit) & f_skr , lastbit)

def singleround(r1,r2,r3,mask1,mask2,mask3):
    (r1_new, o1) = lfsr(r1, mask1, 36)
    (r2_new, o2) = lfsr(r2, mask2, 38)
    (r3_new, o3) = lfsr(r3, mask3, 40)
    val = (o1 * o2) ^ ((o2 ^ 1) * o3)
    for i in range(10):
        (r1_new, o1) = lfsr(r1_new, mask1, 36)
    for i in range(4):
        (r2_new, o2) = lfsr(r2_new, mask2, 38)
    for i in range(6):
        (r3_new, o3) = lfsr(r3_new, mask3, 40)
    return (r1_new,r2_new,r3_new,val)

r1 = secret.r1
r2 = secret.r2
r3 = secret.r3
assert secret.flag=="flag{"+hashlib.sha256(long_to_bytes((r1<<78) ^ (r2<<40) ^ (r3))).hexdigest()+"}"
assert hashlib.sha256(secret.flag).hexdigest()=="c7d15305d893e66663f9b659da25f2f952f826658fd95b27b1062d2d67963a00"

mask1=0b1101011011111000110001000101010111101
mask2=0b110110110100011100001111110110011110111
mask3=0b10000001101111100011100010001101011101011

s=""
for i in range(1024*1024):
    if i % 1024 == 0:
        print i/1024, "/ 1024"
    tmp=0
    for j in range(8):
        (r1,r2,r3,output)=singleround(r1,r2,r3,mask1,mask2,mask3)
        tmp = (tmp << 1) ^ output
        for k in range(18):
            (r1, r2, r3, output) = singleround(r1, r2, r3, mask1, mask2, mask3)
    s+=chr(tmp)
open("output","wb").write(s)