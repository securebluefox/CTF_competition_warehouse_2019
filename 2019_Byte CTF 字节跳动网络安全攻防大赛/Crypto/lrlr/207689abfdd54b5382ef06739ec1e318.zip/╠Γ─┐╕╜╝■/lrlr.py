from Crypto.Util.number import getPrime, bytes_to_long, long_to_bytes
from Crypto.Cipher import AES
import random


class lrand:

    def __init__(self, seed):
        self.seed = seed
        self.states = self.gen_states()
        self.statespoint = 0
        self.stateselse = 24

    def generate_init_state(self):
        a = 0
        for i in bin(self.seed)[2:]:
            a = a << 1
            if (int(i)):
                a = a ^ self.seed
            if a >> 256:
                a = a ^ 0x10000000000000000000000000000000000000000000000000000000000000223L
        return a

    def gen_states(self):
        init_state = self.generate_init_state()
        e = 17
        clist = []
        nlist = []
        for i in range(24):
            p = getPrime(512)
            q = getPrime(512)
            n = p * q
            c = pow(init_state, e, p * q)
            nlist.append(n)
            clist.append(c)
        f = open("cl", "wb")
        for i in nlist:
            f.write(hex(i) + "\n")
        return clist

    def stateconvert(self, state):
        key = long_to_bytes(random.getrandbits(128))
        handle = AES.new(key, AES.MODE_CBC, "\x00"*16)
        output = handle.encrypt(long_to_bytes(state))
        return output

    def gen_new_states(self):
        for i in range(24):
            key = long_to_bytes(random.getrandbits(128))
            handle = AES.new(key, AES.MODE_CBC, "\x00"*16)
            tmpstate=handle.encrypt(long_to_bytes(self.states[self.statespoint-24+i]))
            self.states.append(bytes_to_long(tmpstate))
        self.stateselse += 24

    def lrandout(self):
        if self.stateselse > 0:
            self.stateselse -= 1
            tmp = self.states[self.statespoint]
            self.statespoint += 1
            return self.stateconvert(tmp)
        else:
            self.gen_new_states()
            return self.lrandout()


def oldtest():
    f=open("old","wb")
    s=""
    for i in range(1000):
        s+=str(random.getrandbits(32))+"\n"
    f.write(s)


def newtest():
    handle = lrand(bytes_to_long(open("flag", "rb").read().strip()))
    for i in range(24):
        handle.lrandout()
    f = open("new", "wb")
    s = ""
    for i in range(24):
        s+=handle.lrandout().encode("hex")+"\n"
    f.write(s)


oldtest()
newtest()