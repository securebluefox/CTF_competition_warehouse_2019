from Crypto.Cipher import AES
from Crypto.Random.random import getrandbits
from Crypto.Util.Padding import pad
from gmpy2 import invert
import hashlib

from secret.flag import flag

p=83476586761942642186824367673728074376945513873131649
m=48505028212961273554241342142547367737355614636391211
n=36416349773946355961809496075344464117276158496122011
I=(45021589112214172249777082330442736567263217043722529, 9642418734668489948359782981587970166509047858232959)
II=(59604720700079284292922465123070607811223543811335956, 35452858912643373215356805762556614156906611990594103)

def iteration(I0,I1):
    a1,b1=I0
    a2,b2=I1
    t=n*a1*a2*b1*b2
    a3=(a1*b2+a2*b1)*invert(1+t,p)%p
    b3=(b1*b2-m*a1*a2)*invert(1-t,p)%p
    return (int(a3),int(b3))

def fast_iter(times,I):
    O=(0,1)
    for i in range(100, -1, -1):
        O=iteration(O,O)
        if (times >> i) % 2 == 1:
            O=iteration(O,I)
    return O

r=getrandbits(100)
print(fast_iter(r, I))
key=hashlib.sha256(str(fast_iter(r, II)).encode("UTF-8")).digest()
cipher=AES.new(key, AES.MODE_ECB)
print(cipher.encrypt(pad(flag.encode("UTF-8"), 16)).hex())