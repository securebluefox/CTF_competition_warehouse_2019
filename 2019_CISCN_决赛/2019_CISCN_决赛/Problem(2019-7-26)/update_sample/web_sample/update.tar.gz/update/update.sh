#!/bin/sh
mv -f index.php /var/www/html/index.php
