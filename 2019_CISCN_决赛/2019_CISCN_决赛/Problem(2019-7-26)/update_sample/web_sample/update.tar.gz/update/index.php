<div class="page-header">
<br><br>
<h1>My first website.</h1>
<p class="lead">This is the first website I built. It seems that there are a lot of loopholes. Can you help me find it?</p>

</div>
<?php
include('header.php');
require_once('config.php');
if (isset($_GET['id'])) {
	$id = waf($_GET['id']);
	$id = int($id);
	$sql = "SELECT * FROM user WHERE id =".$id;
	$data = mysqli_multi_query($connect,$sql) or die('<center><h3>Error!</h3></center><br>');
	$result = mysqli_store_result($connect);
	$row = mysqli_fetch_row($result);
	if ($_SESSION['user_id'] == $id) {
		echo "<center><h3>Hello ".$_SESSION['username']."</h3></center><br>";
	}else{
		echo "<center><h3>NO!!! You are not ".$row[1]."</h3></center><br>";
	}
	mysqli_free_result($result);
	mysqli_close($connect);
}

if(isset($_SESSION['username'])){
	if($_SESSION['username'] !== 'admin') {
		echo '<center><h3>Only the admin can see something differently.</h3></center><br>';
	}else{
		echo "<center><h3>you can do it!</h3><br>";
		echo "<a href=\"Wc56cOdf86cKd201748Jdo4c8w5/index.php\" class=\"btn btn-lg btn-success\">Let's play a game!</a>";
	}
}else{
	echo "<center><h3>Please log in first!</h3></center><br>";
}
?>