# Usage

- replace the binary `chall` and `flag`
- adding source code and makefile is suggested
- modify the service name and username as you like
- note the resource limit and the wrapper's content, modify it as you like
- `docker network create pwn`
- `docker-compose up -d` to build, create and start
- `docker-compose down` 
